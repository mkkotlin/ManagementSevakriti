package com.mayank.managementsevakriti.contractor

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.mayank.managementsevakriti.R

class ContractorRegistrations : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contractor_registation)
    }
}